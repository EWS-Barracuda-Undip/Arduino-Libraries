# AutoPID
Arduino AutoPID library

A simple PID library featuring time scaling, bang-bang control, and PWM relay control.

[Full Documentation](http://ryandowning.net/AutoPID)
